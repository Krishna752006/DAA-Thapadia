import java.util.*;
class Solution
{
    public static void main(String[] main)
    {
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        char[] ch = s.toCharArray();
        for(int i = ch.length-1;i>)
        sc.close();
    }
}