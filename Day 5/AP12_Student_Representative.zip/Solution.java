import java.util.*;
class Solution
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int arr[] = new int[a];
        for(int i = 0;i<a;i++)
        arr[i] = i+1;
        int t = a,c = 0,i = 0;
        while(t > 1)
        {
            if(arr[i] != -1) 
            {
                c++;
                if(c == b)
                {
                    arr[i] = -1;
                    c = 0;
                    t--;
                }
            }
            i = (i+1)%a;
        }
        for(int j = 0;j<a;j++)
        {
            if(arr[j] != -1)
            {
                System.out.print(j+1);
                break;
            }
        }
        sc.close();
    }
}