import java.util.*;
class Solution
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt(),b = 0;
        int arr[] = new int[a];
        for(int i = 0;i<a;i++)
        {
            arr[i] = sc.nextInt();
        }
        int l = 0,r = a-1,k = -1;
        while(l<=r)
        {
            int m = l + (r-l)/2;
            if(arr[m] == 1)
            {
                k = m;
                r = m - 1;
            }
            else if(arr[m] < 1)
            l = m + 1;
        }
        if(k == -1) System.out.print(0);
        else System.out.print(a-k);
        sc.close();
    }
}